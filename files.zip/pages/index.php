<?php /* Template Name: Home */ ?>
<!DOCTYPE html>
<html lang="en" class="no-js" xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<link rel="dns-prefetch" href="//ajax.googleapis.com" />
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="format-detection" content="telephone=no"/>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous" />
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css" type="text/css" media="all" />	
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/ninja.css" type="text/css" media="all" />	
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/animate.css" type="text/css" media="all" />
	<link rel="apple-touch-icon" href="<?php bloginfo('template_url'); ?>/images/apple-touch-icon.png"/> 
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i|Noto+Serif" rel="stylesheet" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
	<?php 
	    /* Always have wp_head() just before the closing </head>
	     * tag of your theme, or you will break many plugins, which
	     * generally use this hook to add elements to <head> such
	     * as styles, scripts, and meta tags.
	     */
	    wp_head();
	 ?>
	<style>
		html {
		    margin-top: 0 !important;
		}	
	</style>
</head> 
    <body class="<?php echo basename(get_permalink()); ?> design Home Home">
<header class="header-page-wrap">
<div class="container-header">
<div class="container-header-flex">
<a class="brand" href=<?php echo home_url(); ?>>
<img alt="Pelaia Law Center - Personal Injury Lawyer " class="brand-image" src="<?php bloginfo('template_url'); ?>/images/logo.png"/>
</a>
<div class="container-nav-main" data-set="nav-main">
<nav class="nav-main fl-drop" data-bp="750" id="nav-main" role="navigation">
<ul>
<li><a class="current" href=<?php echo home_url(); ?>>Home</a></li>
<li><a href="<?php echo get_site_url(); ?>/Meet-Ralph/">Meet Ralph</a></li>
<li><a href="<?php echo get_site_url(); ?>/Results.shtml">Results</a></li>
<li><a href="<?php echo get_site_url(); ?>/blog/">Blog</a></li>
<li><a href="<?php echo get_site_url(); ?>/Videos.shtml">Videos</a></li>
<li><a href="<?php echo get_site_url(); ?>/Contact.shtml">Contact Me</a></li>
<li class="togglebox-close"><a class="close" data-target="nav-main" href="javascript:void(0);"><span aria-hidden="true" class="fas fa-times"> </span>Close</a></li>
</ul>
</nav>
</div>
<div class="cta">
<div class="cta-text">Schedule Your Free Consultation</div>
<div class="cta-phone">903-704-4375</div>
</div>
</div>
</div>
</header>
<div class="mobile-navigation-wrap">
<div class="mobile-navigation">
<div class="mobile-nav">
<a class="btn-nav-main-mobile btn-togglebox" data-target="nav-main" href="javascript:void(0);"><span aria-hidden="true" class="fas fa-bars"> </span>Menu</a>
<a class="btn-contact-mobile" href="<?php echo get_site_url(); ?>/Contact.shtml">Contact</a>
</div>
<div class="nav-main-mobile" data-set="nav-main"> </div>
<a class="btn-nav-practice-mobile" data-target="nav-practice" href="javascript:void(0);"><span aria-hidden="true" class="fas fa-bars"> </span>View All Legal Services</a>
<div class="practice-area-mobile" data-set="nav-practice"> </div>
</div>
</div>
<div class="container-columns-wrap">
<div class="banner-text">
<em>Experience</em> Counts
            <p><span class="italic">I am attorney Ralph Pelaia</span>, and I have been helping people with their
                personal injury claims for over four decades. <span class="last">Call me, I can help.</span></p>
<a class="btn" href="javascript:void(0)" id="learn-more">Learn More</a>
<a class="scroll" href="javascript:void(0)" id="scroller-1"><span class="up">scroll</span> <span class="bottom"> </span> </a>
</div>
<div class="attorney">
<img alt="Ralph Pelaia" src="<?php bloginfo('template_url'); ?>/images/home-attr.jpg"/>
</div>
</div>
<div class="module1">
<div class="mod1-left">
<a href="<?php echo get_site_url(); ?>/Meet-Ralph/"><span class="rotate">MEET Ralph Pelaia <span class="fas fa-angle-double-right"> </span></span></a>
</div>
<div class="mod1-right">
<h1 class="page-title"><?php echo get_the_title(); ?>, Results-Based Representation</h1>

    <article class="content" id="content">
    <?php
        wp_reset_query(); // necessary to reset query
        while ( have_posts() ) : the_post();
            the_content();
        endwhile; // End of the loop.
    ?>
    </article>
    
</div>
</div>
<div class="module2">
<div class="mod-content">
<p>Having an attorney on your side can make all the difference in a contested case. </p>
<p> The sooner you reach
                out, the sooner I can discuss what I can do to help you recover fair compensation.</p>
<h3><em>Help Starts Here</em> â Select Your Legal Issue:</h3>
<div class="nav-practice-desktop" data-set="nav-practice">
<nav class="nav-practice fl-drop" data-bp="750" id="nav-practice" role="navigation">
<!-- ### START PA ### -->
<ul>
<li class="common mod2-left">
<a href="<?php echo get_site_url(); ?>/Motor-Vehicle-Accidents/">
<div class="over">
<h4>Motor Vehicle Accidents </h4>
<p>If you were seriously injured in an accident, I will fight the insurance
                                        companies for you. </p>
<p>Read More <span class="fas fa-angle-double-right"> </span></p>
</div>
<h4>Motor Vehicle Accidents <span class="fas fa-angle-double-right"> </span></h4>
</a>
</li>
<li class="common mod2-right">
<a href="<?php echo get_site_url(); ?>/Personal-Injury/">
<div class="over">
<h4>Personal Injuries</h4>
<p>I have extensive experience handling a range of various personal injury claims.
                                    </p>
<p>Read More <span class="fas fa-angle-double-right"> </span></p>
</div>
<h4>Personal Injuries <span class="fas fa-angle-double-right"> </span></h4>
</a>
</li>
</ul>
<!-- ### END PA ### -->
</nav>
</div>
</div>
<a class="scroll" href="#" id="scroller-2"><span class="up">scroll</span> <span class="bottom"> </span> </a>
</div>
<div class="module3-wrap">
<div class="module3">
<div class="mod3-top">
<div class="mod3-top-left">
<h3>
<em>Understand</em> That Insurance Companies Are Not Your Friends
				</h3>
<p>After your accident, the insurance company adjusters immediately get to work trying to assign a value to your case. They then may attempt to contact you "just to touch base" to see how you are feeling or learn more about any medical care you may be receiving. Know that these insurance companies are looking out for their best interests. They want you to make mistakes or statements that severely diminish the compensation you are entitled to receive.</p>
</div>
<div class="mod3-top-right">
<a href="<?php echo get_site_url(); ?>/Meet-Ralph/"><span class="rotate">REQUEST A MEETING <span class="fas fa-angle-double-right"> </span></span></a>
</div>
</div>
<div class="mod3-bottom">
<div class="mod3-bottom-left">
<p>As your attorney, it is my job to stand up these insurance companies. With over 40 years of legal experience inside and outside of the courtroom, I am not afraid to go in whatever direction your case may take us. I am not here to make an insurer's job easier. I am going to work hard to get you a fair offer, and to go to trial if the insurance companies do not want to bargain.</p>
</div>
<div class="mod3-bottom-right">
<script>var videoIds=[];</script>
<div class="flv-player-wrapper single-title-player flv-md">
<div class="flv-player-container flv-player-container-6012418664001" data-autoplay="false" data-player-type="single-title-player" data-playlist-id="null" data-transcript="false" id="flv-player-container-6012418664001" itemscope="itemscope" itemtype="http://schema.org/VideoObject">
<meta content="Personal Injury - Ralph Pelaia" itemprop="name"/>
<meta content="Pelaia Law Center" itemprop="description"/>
<meta content="/Personal-Injury-Ralph-Pelaia.shtml" itemprop="url"/>
<meta content="https://brightcove.hs.llnwd.net/v1/unsecured/media/981571817/201903/406/981571817_6012424440001_6012418664001-vs.jpg?pubId=981571817" itemprop="thumbnailUrl"/>
<meta content="2019-03-11T08:51:36+00:00" itemprop="uploadDate"/>
<video class="video-js flv-video" controls="controls" data-account="981571817" data-application-id="" data-embed="default" data-player="r1wbDQEM-" data-video-id="6012418664001" id="flv-player-6012418664001">
</video>
<script src="//players.brightcove.net/981571817/r1wbDQEM-_default/index.min.js"></script>
<script type="text/JavaScript">
	if ('false' == 'true') {
	   var myVideo = videojs('flv-player-6012418664001');
	   myVideo.on('loadedmetadata', function() { myVideo.play(); });
	}
    </script>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="module4-wrap">
<div class="module4">
<h3><em>Recovered</em> Millions In Past Verdicts And Settlements</h3>
<ul>
<li>
<a class="ver-1" href="javascript:void(0)">
<p>Ralph Pelaia has been voted the âBest Attorney in East Texasâ by the readers of the Longview
                            New-Journal in the annual âBest of East Texasâ awards.</p>
<p>MORE AWARDS <span class="fas fa-angle-double-right"> </span></p>
</a>
</li>
<li>
<a class="ver-2" href="javascript:void(0)">
<p>In 2013, Ralph Pelaia was named for membership in the âThe National Trial Lawyers: Top 100â
                            an invitation-only organization composed of premier trial lawyers...</p>
<p>MORE MEMBERSHIPS <span class="fas fa-angle-double-right"> </span></p>
</a>
</li>
<li>
<a class="ver-3" href="javascript:void(0)">
<p>Ralph Pelaia handled the Longview âGood Samaritanâ death case. A young man on his way to work
                            stopped to give aide to a DPS officer whose vehicle had wrecked.</p>
<p>MORE OUTCOMES <span class="fas fa-angle-double-right"> </span></p>
</a>
</li>
</ul>
</div>
</div>
<div class="short-form-button-wrap">
<a class="btn short-form-btn" href="<?php echo get_site_url(); ?>/Contact.shtml"> Send Email</a>
</div>
<div class="short-form-wrap">
<div class="short-form-container">
<a class="scroll" href="#" id="scroller-3"><span class="up">scroll</span></a>
<div class="short-form-content">
<h3><em>Schedule</em> Your Free Consultation With An Experienced Lawyer Today</h3>
<p>If you have been seriously injured or lost a loved one due to another's negligence anywhere in east
                    Texas, call me, I can help. I will be the one personally handling your case, and you will be able to
                    speak to me when you have questions throughout the process. You may reach my Longview office at
                    903-704-4375 or by sending an email to arrange your free consultation.</p>
</div>
<div class="container-short-form">
<div class="container-module container-module-short-form">
<div class="module module-short-form">

    <?php 
        if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Side Bar") ) : 
    ?>
    <?php endif;?>
    
</div>
</div>
</div>
</div>
</div>
<div class="badges">
<div class="badge">
<ul>
<li>
<img alt="Multi Million Dollar Advocates Forum" src="<?php bloginfo('template_url'); ?>/images/badge-1.jpg"/>
</li>
<li>
<img alt="Multi Million Dollar Advocates Forum" src="<?php bloginfo('template_url'); ?>/images/badge-2.jpg"/>
</li>
<li>
<img alt="2014 Litigator Awards Ranked Top 1% Of Lawyers" src="<?php bloginfo('template_url'); ?>/images/badge-3.jpg"/>
</li>
<li>
<img alt="The National Top 100 Trial Lawyers Trial Lawyers" src="<?php bloginfo('template_url'); ?>/images/badge-4.jpg"/>
</li>
</ul>
</div>
</div>
<div class="footer-wrap">
<footer class="footer-page">
<div class="contact-info">
<div class="offices horizontal" id="offices" itemref="attorneyProfile attorney-list">
<div class="office office-1 office-odd office-first office-last office-longview">
<p>
<strong class="office-title">Pelaia Law Center</strong>
<span class="office-address">
<span class="office-street-address"> 133 E Tyler St </span>
<span class="office-locality">Longview</span>, 
                <span class="office-region">TX</span>
<span class="office-postal-code">75601</span>
</span>
<span class="office-phone office-phone-local office-phone-tracking">
<span class="office-phone-label">Phone</span>: 
                <span class="office-phone-number" data-raw-number="9037044375">903-704-4375</span>
</span>
<a class="office-page-link" href="<?php echo get_site_url(); ?>/Longview-Personal-Injury-Office.shtml" target="_self" title="Longview Law Office Map"> Longview Law Office Map </a>
</p>
<!-- 
The automatically generated embedded map requires a street address, locality, and postal code in the Client Info Doc -->
</div>
</div>
</div>
<div class="social">
<ul>
<li>
<a href="https://www.facebook.com/pelaialaw/" target="_blank">
<span aria-hidden="true" class="fab fa-facebook-f"> </span>
</a>
</li>
<li>
<a href="https://www.youtube.com/user/PelaiaLawCenter" target="_blank">
<img alt="YouTube" src="<?php bloginfo('template_url'); ?>/images/youtube-ico.png"/>
</a>
</li>
<li>
<a href="https://twitter.com/PelaiaLaw" target="_blank">
<span aria-hidden="true" class="fab fa-twitter"> </span>
</a>
</li>
<!-- <li>
                        <a href="javascript:void(0)" class="review-us btn">Review Us</a>
                    </li> -->
</ul>
</div>
<div class="footer-flex">
<section class="fine-print clearfix"><p class="copyright">Â© 2019 by <a href="https://pview.findlaw.com/cmd/view?wld_id=3855634&amp;pid=1" target="_blank">Pelaia Law Center</a>. All rights reserved. <a href="<?php echo get_site_url(); ?>/Disclaimer.shtml">Disclaimer</a> | <a href="<?php echo get_site_url(); ?>/Site-Map.shtml">Site Map</a></p><p class="branding"><a href="<?php echo get_site_url(); ?>/Privacy-Policy.shtml" id="PrivacyPolicy">Privacy Policy</a> | <a href="https://www.lawyermarketing.com/?utm_source=FirmSite&amp;utm_medium=footer%2Bcopyright&amp;utm_term=law%2Bfirm%2Bmarketing&amp;utm_campaign=FirmSite%2BInbound" rel="nofollow" target="_blank">Business Development Solutions</a> by <a href="https://www.findlaw.com/" target="_blank">FindLaw</a>, part of Thomson Reuters. 
</p></section>
</div>
<a class="back-to-top btn" href="javascript:void(0)">
<span class="fas fa-angle-up"> </span>
</a>

    </footer>
    <?php wp_footer(); ?>
    
</div>
<!--[if lt IE 9]>
        <script src="/includes/scripts/respond-1.1.0.js"></script>
    <![endif]-->
<link href="https://fonts.googleapis.com/css?family=Lora:400,400i|Poppins:400,600,700" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"> </script>
<script>var highlightOptions = { pageID: 'Home', pageSection: '', pageSectionTop: '' }</script>
<script src="/includes/scripts/combined-intake-form.js" type="text/javascript"> </script>
<script src="/includes/scripts/flDefault-1.0.0.js"> </script>
<script src="<?php echo get_template_directory_uri(); ?>/flScripts-1.0.1.js"> </script>
<script src="/includes/scripts/jquery.flexslider-2.1.js">//</script>
<script src="<?php echo get_template_directory_uri(); ?>/init.js"> </script>
<script src="/includes/autolink-phone.js"> </script>
<script><!--
        var words = $("h1").text().trim().split(' ');
        words[0] = '<span class= "italic">' +  words[0] + '</span>';
        words[2] = '<span class="italic">' + words[2] + '<span> ';
        $("h1").html(words.join(' ')); 
    --></script>
<!-- START flTag Footer -->
<script language="JavaScript" type="text/javascript">
var FL = FL || {};
FL = 
{
  "account": {
    "accountId": 3855634,
    "siteId": 67165,
    "subscriptionId": "3187113",
    "pixelReady": true
  },
  "adobeAnalytics": {
    "prodReportSuites": "findlaw-42973,findlaw-global-v1,findlawfirmstaging",
    "stageReportSuites": "findlawfsindividualstage,findlawfsglobalstage,findlawglobalstage"
  }
};
</script>
<script src="//assets.adobedtm.com/9725f37c2c3899053569bb6afb8a3d51bc224d94/satelliteLib-5ac9f7d6c64aaca0ea4f2c891947b1261d9c0e6e.js"></script>
<script type="text/javascript">_satellite.pageBottom();</script>
<!-- END flTag Footer -->
</body>
</html>