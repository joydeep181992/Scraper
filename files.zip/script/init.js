$(function () {
	// Detect Publisher "Edit" view
	if (location.href.indexOf('JSPeditPageContent.do') > 0) {
		// Code here will run when viewing site in Edit View - needed when certain elements break Edit View
		// Example: $('.container-accolades, .container-tagline').remove();
	} else {
		// Code in this section will not run on Publisher edit view

		// Fix link targets (v1.0.2)
		(function () { if ($(document.body).hasClass("fl-target-ignore") === !0) return !1; var t = location.protocol + "//" + location.host, a = /\.(?:pdf|docx?|xlsx?|pptx?|xml)(?:\?.*)?$/i, l = /\?.*/i; $("a").each(function (r, o) { var i = $(o), e = i.attr("href"), n = o.href; return void 0 !== e && (e = e.replace(l, "")), void 0 !== n && (n = n.replace(l, "")), void 0 === e || i.hasClass("fl-target-ignore") === !0 || null !== e.match(/^#/) || null !== e.match(/^javascript:/i) || null !== e.match(/^mailto:/i) || 0 === n.indexOf(t) && null === n.match(a) ? !0 : void i.attr("target", "_blank") }) }());
		$('#nav-main').appendAround();
		$('.nav-practice').appendAround();
	}
});

$('#containerIntakeFormShortAutofill p.intakeFormShortPrivacy a').appendTo('#containerIntakeFormShortAutofill .formCheck');

$('.btn-nav-main-mobile').click(function () {
	$('.nav-practice').removeClass('fl-show');
});

$('.btn-nav-practice-mobile').click(function () {
	$('.nav-main').removeClass('fl-show');
});

$('<li class="togglebox-close"><a href="javascript:void(0);" class="close" data-target="nav-practice"><span class="fas fa-times" aria-hidden="true"></span>Close</a></li>').insertAfter('.nav-practice >ul >li:last-child');


$('.back-to-top').click(function () {
	$('body,html').animate({ scrollTop: 0 }, 800);
	return false;
});

// $(".container-buttons").appendTo(".office-phone-tracking");
// $(".office-map-link").insertAfter(".mail-office");

// $(".office-map-link, .office-page-link").prependTo(".container-contact-info .left-section .container-buttons");

//Scroll to practice areas

$('a[href="#nav-practice"]').on("click", function (e) {
	e.preventDefault();
	$("body,html").animate({ scrollTop: $(".nav-practice-wrap").offset().top }, 800);
});

$('#scroller-1').click(function () {
	$('body, html').animate({
		scrollTop: $('.module1').offset().top - 200 + "px"
	}, 1000);
	return false;
});

$('#scroller-2').click(function () {
	$('body, html').animate({
		scrollTop: $('.module3-wrap').offset().top + "px"
	}, 1000);
	return false;
});

$('#scroller-3').click(function () {
	$('body, html').animate({
		scrollTop: $('.short-form-wrap').offset().top - 200 + "px"
	}, 1000);
	return false;
});


$('#learn-more').click(function () {
	$('body, html').animate({
		scrollTop: $('.short-form-wrap').offset().top - 400 + "px"
	}, 1000);
	return false;
});

if (window.innerWidth > 750) {
  $(window).scroll(function () {
    if ($(window).scrollTop() > 150 && window.innerWidth > 750) {
      $(".header-page-wrap").addClass("sticky-nav");
    } else {
      $(".header-page-wrap").removeClass("sticky-nav");
    }
  });
}


