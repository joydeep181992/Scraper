<!DOCTYPE html>
<!--[if lte IE 7]><html id="ie" class="no-js lt-ie10 lt-ie9 lt-ie8" lang="en" xmlns="http://www.w3.org/1999/xhtml"><![endif]-->
<!--[if IE 8]><html id="ie8" class="no-js lt-ie10 lt-ie9" lang="en" xmlns="http://www.w3.org/1999/xhtml"><![endif]-->
<!--[if IE 9]><html id="ie9" class="no-js lt-ie10" lang="en" xmlns="http://www.w3.org/1999/xhtml"><![endif]-->
<!--[if gt IE 9]><!-->
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://www.facebook.com/2008/fbml" xmlns:og="http://opengraphprotocol.org/schema/" lang="en" class="no-js">
<!--<![endif]-->

<head>
<title>Page Not Found | Pelaia Law Center | Longview, Texas</title>
    <meta charset="utf-8" />
    <meta name="FSLanguage" content="en-US" />
<meta name="FSOnHomePage" content="no" />
<meta name="FSOnInsertLink" content="no" />
<meta name="FSOnSitemap" content="no" />
<meta name="FSSearchable" content="no" />
<meta name="FSSection" content="Root" />
<meta name="FSPageName" content="Page Not Found" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta http-equiv="content-language" content="en-US" />
    <link rel="dns-prefetch" href="//ajax.googleapis.com" />
    
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="format-detection" content="telephone=no" />
<meta content="https://plclotx.firmsitepreview.com/Custom-404.shtml" property="og:url" />
<meta content="website" property="og:type" />
<meta content="Page Not Found | Pelaia Law Center | Longview, Texas" property="og:title" />
<meta content="en_US" property="og:locale" />
<meta content="Pelaia Law Center" property="og:site_name" />
<meta content="https://plclotx.firmsitepreview.com/design/images/og-2019-03-05-09-29-59.png" property="og:image" />
<meta name="robots" content="noindex, follow" />

    <link rel="stylesheet" href="/design/css/site.css" />
    <!-- <link rel="stylesheet" href="http://localhost:3000/design/css/site.css" /> -->
   <link rel="icon" href="data:image/x-icon;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQEAYAAABPYyMiAAAABmJLR0T///////8JWPfcAAAACXBIWXMAAABIAAAASABGyWs+AAAAF0lEQVRIx2NgGAWjYBSMglEwCkbBSAcACBAAAeaR9cIAAAAASUVORK5CYII=" />
    <link rel="apple-touch-icon" href="/design/images/apple-touch-icon.png" />

    

           
<link rel="canonical" href="https://plclotx.firmsitepreview.com/Custom-404.shtml" />

<!-- No flTag Header -->






<script type="text/javascript">
var fs3_inPublish = true; // a flag to mark publish mode
var FSSitePath = '';
function BuildPath(path){
	return path;
}
</script>
<script type="application/ld+json">{
	"@context" : "http://schema.org",
	"@type" : "LegalService",
	"@id" : "https://www.pelaialaw.com",
	"image" : "https://wldimages.findlaw.com/images/3855634/3855634_1.jpg",
	"name" : "Pelaia Law Center",
	"telephone" : "9037044375",
"address" : {
	"@type" : "PostalAddress",
	"streetAddress" : "133 E Tyler St",
	"addressLocality" : "Longview",
	"addressRegion" : "TX",
	"postalCode" : "75601",
	"addressCountry" : "US"
}
}</script>

</head>

<body class="design Custom-404  ">
    <header class="header-page-wrap">
        <div class="container-header">
            <div class="container-header-flex">
                <a href="/" class="brand">
                    <img src="/design/images/logo.png" alt="Pelaia Law Center - Personal Injury Lawyer " class="brand-image" />
                </a>
                <div class="container-nav-main" data-set="nav-main">
                    <nav id="nav-main" class="nav-main fl-drop" data-bp="750" role="navigation">
                        <ul>
                            <li><a href="/">Home</a></li>
                            <li><a href="/Meet-Ralph/">Meet Ralph</a></li>
                            <li><a href="/Results.shtml">Results</a></li>
                            <li><a href="/blog/">Blog</a></li>
                            <li><a href="/Videos.shtml">Videos</a></li>
                            <li><a href="/Contact.shtml">Contact Me</a></li>
                            <li class="togglebox-close"><a href="javascript:void(0);" class="close" data-target="nav-main"><span class="fas fa-times" aria-hidden="true"> </span>Close</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="cta">
                    <div class="cta-text">Schedule Your Free Consultation</div>
                    <div class="cta-phone">903-704-4375</div>
                </div>
            </div>
        </div>
    </header>
    <div class="mobile-navigation-wrap">
        <div class="mobile-navigation">
            <div class="mobile-nav">
                <a href="javascript:void(0);" class="btn-nav-main-mobile btn-togglebox" data-target="nav-main"><span class="fas fa-bars" aria-hidden="true"> </span>Menu</a>
                <a href="/Contact.shtml" class="btn-contact-mobile">Contact</a>
            </div>
            <div class="nav-main-mobile" data-set="nav-main"> </div>

            <a href="javascript:void(0);" class="btn-nav-practice-mobile" data-target="nav-practice"><span class="fas fa-bars" aria-hidden="true"> </span>View All Legal Services</a>
            <div class="practice-area-mobile" data-set="nav-practice"> </div>
        </div>
    </div>
    <div class="container-columns-wrap">
        <div class="container-columns">
            <div class="container-column-main">
                <div class="column-main" role="main">
                    <h1 class="page-title">
                        Page Not Found
                    </h1>
                    <article class="content" id="content">
                        
<p>It looks like the page you are looking for is missing. This could be due to  an incorrect URL or from following an incorrect link.</p>
<p>The following are other pages you may find helpful:</p>
<ul>
	<li><a href="/">Home</a></li>
	<li><a href="/Contact.shtml">Contact</a></li>
	<li><a href="/Site-Map.shtml">Site Map</a></li>
</ul>
                    </article>
                </div>
            </div>
            <div class="column-side" role="complementary">
                <div class="attorney-wrap">
                    <div class="attorney">
                        <img src="/design/images/attorney.jpg" alt="Ralph Pelaia" />
                    </div>
                </div>
                <div class="nav-practice-desktop" data-set="nav-practice">
                    <nav id="nav-practice" class="nav-practice fl-drop" data-bp="750" role="navigation">
                        <!-- ### START PA ### -->
                        <ul>
                                <li class="motor"><a href="/Motor-Vehicle-Accidents/">
                                        <div class="over">
                                            <h4>Motor Vehicle Accidents </h4>
                                            <p>If you were seriously injured in an accident, I will fight the insurance
                                                companies for you. </p>
                                            <p>Read More <span class="fas fa-angle-double-right"> </span></p>
                                        </div>
                                        <h4>Motor Vehicle Accidents <span class="fas fa-angle-double-right"> </span></h4>
                                    </a>
                                </li>
                                <li class="pers"><a href="/Personal-Injury/">
                                        <div class="over">
                                            <h4>Personal Injuries</h4>
                                            <p>I have extensive experience handling a range of various personal injury
                                                claims.</p>
                                            <p>Read More <span class="fas fa-angle-double-right"> </span></p>
                                        </div>
                                        <h4>Personal Injuries <span class="fas fa-angle-double-right"> </span></h4>
                                    </a>
                                </li>
                        </ul>
                        <!-- ### END PA ### -->
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="short-form-button-wrap">
        <a class="btn short-form-btn" href="/Contact.shtml">Send Email</a>
    </div>
    <div class="short-form-wrap">
        <div class="short-form-container">
            <div class="short-form-content">
                <h3><em>Schedule</em> Your Free Consultation With An Experienced Lawyer Today</h3>
                <p>If you have been seriously injured or lost a loved one due to another's negligence anywhere in east
                    Texas, call me, I can help. I will be the one personally handling your case, and you will be able to
                    speak to me when you have questions throughout the process. You may reach my Longview office at
                    903-704-4375 or by sending an email to arrange your free consultation.</p>
            </div>
            <div class="container-short-form">
                <div class="container-module container-module-short-form" >
    <div class="module module-short-form">
        <div id="containerIntakeFormShortAutofill">
            <p>
                <strong>Bold</strong> labels are required.
            </p>
            <form method="post" action="/cgi-bin/emailservice.cgi" name="intakeFormShortAutofill" id="intakeFormShortAutofill" class="formAutoFill">
                
<input name="serverTime" type="hidden" value="1561371205" />
                <input type="hidden" name="SubscriptionID" value="3187113"/>
                <input type="hidden" name="email_subject" value="Findlaw FirmSite Message From SiteDomain"/>
                <input type="hidden" name="removeFLBranding" value="false"/>
                <input type="hidden" name="guid" value="c8or0jdl7S1TgfY9kQud8V48Eyn+sUanDpAA22wsKpotaYx/mHugeSC7tU5exafPhTzNQLK9TtF+W9LEi6iSBmaE7XR002gY6BEkMD/6sDQrNO5ASim/Ro+KQNX2IMHphS7xIAH9VbgKHLZTzbxsUePZ9cBk6qSekPWnX+cN0H8="/>
                <input type="hidden" name="wld_id" value="3855634"/>
                <input type="hidden" name="thankyouPage" value="Thank-You"/>
                <fieldset>
                    <legend>
                        <span>Contact Information</span>
                    </legend>
                    <label for="intakeFormShortName">Name</label>
                    <div class="formHighlight">
                        <input type="text" name="Name|at:name||Please enter your name." id="intakeFormShortName" title="Name"/>
                    </div>
                    <label for="intakeFormShortEmail">
                        <strong>Email Address</strong>
                    </label>
                    <p data-for="intakeFormShortEmail" role="alert" class="formHide">
                        <strong>Please enter a valid email address.</strong>
                    </p>
                    <div class="formHighlight">
                        <input type="text" name="Email Address|at:email|r|Please enter a valid email address." id="intakeFormShortEmail" class="validate email" title="Email Address"/>
                    </div>
                    <label for="intakeFormShortPhone">Phone</label>
                    <p data-for="intakeFormShortPhone" role="alert" class="formHide">
                        <strong>Please enter a valid phone number. You may use 0-9, spaces and the ( ) - + characters.</strong>
                    </p>
                    <div class="formHighlight">
                        <input type="text" name="Phone|at:phone||Please enter a valid phone number. You may use 0-9, spaces and the ( ) - + characters." id="intakeFormShortPhone" title="Phone" class="dataCheck number"/>
                    </div>
                    <label for="intakeFormShortMessage">Brief description of your legal issue</label>
                    <div class="formHighlight">
                        <textarea name="Brief description of your legal issue|at:message||Please describe your legal issue." id="intakeFormShortMessage" title="Brief description of your legal issue" rows="4" cols="15"></textarea>
                    </div>
                    <div class="formCheck">
                        <p data-for="intakeFormShortAutofillDisclaimerCheck" role="alert" class="formHide">
                            <strong>Please verify that you have read the disclaimer.</strong>
                        </p>
                        <label for="intakeFormShortAutofillDisclaimerCheck">
                            <input type="checkbox" name="Read disclaimer:||r|Please verify that you have read the disclaimer." id="intakeFormShortAutofillDisclaimerCheck" class="validate checkbox" value="yes"/>
                            <strong>I have read the 
                                <span>disclaimer.</span>
                            </strong>
                        </label>
                        <strong>
                            <a class="intakeFormShortDisclaimerLink" href="/Disclaimer.shtml">disclaimer</a>.
                        </strong>
                    </div>
                    <input class="intakeFormHiddenInput" type="hidden" id="checkboxDisclaimerIntakeFormShort" name="cgi|checkboxDisclaimerIntakeFormShort" value="Read disclaimer:||r|Please verify that you have read the disclaimer."/>
                    <div id="intakeFormShortDisclaimer">
                        <div>
                            <p>The use of the Internet or this form for communication with the firm or any individual member of the firm does not establish an attorney-client relationship. Confidential or time-sensitive information should not be sent through this form.</p>
                            <a href="#intakeFormShortAutofillDisclaimerCheck" rel="nofollow">close</a>
                        </div>
                    </div>
                </fieldset>
                <p class="intakeFormShortPrivacy">
                    <a href="/Privacy-Policy.shtml">Privacy Policy</a>
                </p>
                <button name="Submit" value="Submit" class="submit" type="submit" id="intakeFormShortAutofillSubmit">SEND EMAIL</button>
            </form>
        </div>
    </div>
</div>
            </div>
        </div>
    </div>
    <div class="badges">
        <div class="badge">
            <ul>
                <li>
                    <img src="/design/images/badge-1.jpg" alt="Multi Million Dollar Advocates Forum" />
                </li>
                <li>
                    <img src="/design/images/badge-2.jpg" alt="Multi Million Dollar Advocates Forum" />
                </li>
                <li>
                    <img src="/design/images/badge-3.jpg" alt="2014 Litigator Awards Ranked Top 1% Of Lawyers" />
                </li>
                <li>
                    <img src="/design/images/badge-4.jpg" alt="The National Top 100 Trial Lawyers Trial Lawyers" />
                </li>
            </ul>
        </div>
    </div>
    <div class="footer-wrap">
        <footer class="footer-page">
            <div class="contact-info">
                <div class="offices horizontal" id="offices" itemref="attorneyProfile attorney-list">
    <div class="office office-1 office-odd office-first office-last office-longview">
        <p>
            <strong class="office-title">Pelaia Law Center</strong>
            <span class="office-address">
                <span class="office-street-address"> 133 E Tyler St </span>
                <span class="office-locality">Longview</span>, 
                <span class="office-region">TX</span>
                <span class="office-postal-code">75601</span>
            </span>
            <span class="office-phone office-phone-local office-phone-tracking">
                <span class="office-phone-label">Phone</span>: 
                <span class="office-phone-number" data-raw-number="9037044375">903-704-4375</span>
            </span>
            <a class="office-page-link" href="/Longview-Personal-Injury-Office.shtml" title="Longview Law Office Map" target="_self"> Longview Law Office Map </a>
        </p>
        <!-- 
The automatically generated embedded map requires a street address, locality, and postal code in the Client Info Doc -->
    </div>
</div> 

	

            </div>
            <div class="social">
                <ul>
                    <li>
                        <a href="https://www.facebook.com/pelaialaw/" target="_blank">
                            <span class="fab fa-facebook-f" aria-hidden="true"> </span>
                        </a>
                    </li>
                    <li>
                        <a href="https://www.youtube.com/user/PelaiaLawCenter" target="_blank">
                            <img src="/design/images/youtube-ico.png" alt="YouTube" />
                        </a>
                    </li>
                    <li>
                        <a href="https://twitter.com/PelaiaLaw" target="_blank">
                            <span class="fab fa-twitter" aria-hidden="true"> </span>
                        </a>
                    </li>
                    <!-- <li>
                        <a href="javascript:void(0)" class="review-us btn">Review Us</a>
                    </li> -->
                </ul>
            </div>
            <div class="footer-flex">
                <section class="fine-print clearfix">
                    <p class="copyright">©
                        
                        2019 by <a href="https://pview.findlaw.com/cmd/view?wld_id=3855634&amp;pid=1" target="_blank">Pelaia Law Center</a>
                        . All rights reserved. <a href="/Disclaimer.shtml">Disclaimer</a> | <a href="/Site-Map.shtml">Site Map</a>
                    </p>
                    <p class="branding">
                        <a id="PrivacyPolicy" href="/Privacy-Policy.shtml">Privacy Policy</a> | <a target="_blank"  rel="nofollow" href="https://www.lawyermarketing.com/?utm_source=FirmSite&amp;utm_medium=footer%2Bcopyright&amp;utm_term=law%2Bfirm%2Bmarketing&amp;utm_campaign=FirmSite%2BInbound">Business Development Solutions</a> by <a target="_blank" href="https://www.findlaw.com/">FindLaw</a>, part of Thomson Reuters. 

                    </p>
                </section>
            </div>
             <a href="javascript:void(0)" class="back-to-top btn">
                <span class="fas fa-angle-up"> </span>
            </a>
        </footer>
    </div>
    <!--[if lt IE 9]>
        <script src="/includes/scripts/respond-1.1.0.js"></script>
    <![endif]-->
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i|Poppins:400,600,700" rel="stylesheet" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"> </script>
    <script>var highlightOptions = { pageID: 'Custom-404', pageSection: '', pageSectionTop: '' }</script>
    <script src="/includes/scripts/combined-intake-form.js" type="text/javascript"> </script>
    <script src="/includes/scripts/flDefault-1.0.0.js"> </script>
    <script src="/design/scripts/flScripts-1.0.1.js"> </script>
    <script src="/includes/scripts/jquery.flexslider-2.1.js">//</script>
    <script src="/design/scripts/init.js"> </script>
    <script src="/includes/autolink-phone.js"> </script>
    
    <script>
        var words = $(".column-main h1").text().trim().split(' ');
        words[0] = '<span class="italic">' +  words[0] + '</span>';
        $(".column-main h1").html(words.join(' ')); 
    </script>

<!-- START flTag Footer -->
<script language="JavaScript" type="text/javascript">
var FL = FL || {};
FL = 
{
  "account": {
    "accountId": 3855634,
    "siteId": 67165,
    "subscriptionId": "3187113",
    "pixelReady": true
  },
  "adobeAnalytics": {
    "prodReportSuites": "findlaw-42973,findlaw-global-v1,findlawfirmstaging",
    "stageReportSuites": "findlawfsindividualstage,findlawfsglobalstage,findlawglobalstage"
  }
};
</script>
<script src="//assets.adobedtm.com/9725f37c2c3899053569bb6afb8a3d51bc224d94/satelliteLib-5ac9f7d6c64aaca0ea4f2c891947b1261d9c0e6e.js"></script>
<script type="text/javascript">_satellite.pageBottom();</script>
<!-- END flTag Footer -->





</body>

</html>